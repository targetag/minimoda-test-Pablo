# Tests de checkout de MiniModa

Se incluyen los archivos TypeScript usados en la ejecución de Chromium del 9 de noviembre de 2026. checkout.spec.ts contiene siete casos. review.spec.ts contiene los dos casos de precios y navegación.

## Ejecutar desde la carpeta extraída

Usá Node.js 24 y ejecutá:

```powershell
npm ci
npx playwright install chromium
npm run typecheck
npx playwright test tests/checkout --project=chromium --workers=1
npx playwright show-report
```

La demo usa datos sintéticos. La configuración predeterminada genera reportes locales en HTML y JSON. La última ejecución histórica obtuvo 8 aprobados y 1 fallido. CHECKOUT-EMPTY permanece como prueba de regresión.
