import { test, expect } from '../../fixtures/test';
import { caseDetails } from '../../utils/case-details';

function amount(text: string) {
  const match = text.match(/\$\s*(\d[\d.]*)/);
  expect(match, `Importe en «${text}»`).not.toBeNull();
  return Number(match![1].replaceAll('.', ''));
}

test('CHECKOUT-PRICE — mantener el precio entre catálogo, carrito y checkout', caseDetails(
  'CHECKOUT-PRICE', 'Gorrito en stock con al menos dos unidades.',
  'Subtotal de carrito y checkout idéntico. El total de checkout suma subtotal y envío.',
  'QASE_CASE_CHECKOUT_PRICE',
), async ({ page, shop }) => {
  let cartSubtotal: number;
  await test.step('Registrar el precio unitario y agregar dos unidades', async () => {
    await shop.openProduct();
    const price = page.getByTestId('product-price-3');
    await expect(price).toBeVisible();
    const unitPrice = amount(await price.innerText());
    expect(unitPrice).toBeGreaterThan(0);
    await page.getByTestId('add-to-cart-3').click();
    await expect(page.getByTestId('header-cart-count')).toHaveText('1');
    await page.getByTestId('header-cart').click();
    const quantity = page.getByTestId('cart-qty-3');
    const cartTotal = page.getByTestId('cart-total');
    await expect(quantity).toHaveText('1');
    expect(amount(await cartTotal.innerText())).toBe(unitPrice);
    await page.getByTestId('cart-incr-3').click();
    await expect(quantity).toHaveText('2');
    cartSubtotal = amount(await cartTotal.innerText());
    expect(cartSubtotal).toBe(unitPrice * 2);
  });
  await test.step('Abrir checkout y comparar su subtotal con el del carrito', async () => {
    await page.getByTestId('checkout-btn').click();
    await expect(page.getByTestId('checkout-resumen')).toContainText('Gorrito de Lana Osito × 2');
    const subtotal = page.getByTestId('checkout-subtotal');
    await expect(subtotal).toBeVisible();
    expect(amount(await subtotal.innerText())).toBe(cartSubtotal);
  });
  await test.step('Comparar el total con el subtotal y el envío visibles', async () => {
    const summary = page.getByTestId('checkout-resumen');
    const shipping = summary.getByText('Envío', { exact: true });
    const total = summary.getByText('Estimado', { exact: true });
    await expect(shipping).toBeVisible();
    await expect(total).toBeVisible();
    const shippingAmount = amount(await shipping.locator('..').innerText());
    expect(amount(await total.locator('..').innerText())).toBe(cartSubtotal + shippingAmount);
  });
});

test('CHECKOUT-BACK — conservar el carrito al volver desde checkout', caseDetails(
  'CHECKOUT-BACK', 'Gorrito en stock y contexto de navegador nuevo.',
  'Atrás conserva producto y cantidad. Al reabrir checkout se conserva el subtotal.',
  'QASE_CASE_CHECKOUT_BACK',
), async ({ page, shop }) => {
  const cartItem = page.getByTestId('cart-item-3');
  const quantity = page.getByTestId('cart-qty-3');
  const checkout = page.getByTestId('checkout-btn');
  let subtotal: number;
  await test.step('Agregar una unidad y abrir el carrito', async () => {
    await shop.addHatAndOpenCart();
    await expect(quantity).toHaveText('1');
    subtotal = amount(await page.getByTestId('cart-total').innerText());
  });
  await test.step('Abrir checkout y volver con Atrás del navegador', async () => {
    await checkout.click();
    await expect(page.getByTestId('checkout-resumen')).toBeVisible();
    await page.goBack();
    await expect(page).toHaveURL(/\/carrito\/?$/);
    await expect(cartItem).toContainText('Gorrito de Lana Osito');
    await expect(quantity).toHaveText('1');
  });
  await test.step('Reabrir checkout y comprobar la línea y el subtotal', async () => {
    await checkout.click();
    await expect(page.getByTestId('checkout-resumen')).toContainText('Gorrito de Lana Osito × 1');
    expect(amount(await page.getByTestId('checkout-subtotal').innerText())).toBe(subtotal);
  });
});
